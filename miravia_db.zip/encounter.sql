
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `encounter`
--

CREATE TABLE `encounter` (
  `encounterID` varchar(10) NOT NULL,
  `mapID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `encounter`
--

INSERT INTO `encounter` (`encounterID`, `mapID`) VALUES
('1', '1'),
('3', '1'),
('4', '1'),
('2', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `encounter`
--
ALTER TABLE `encounter`
  ADD PRIMARY KEY (`encounterID`),
  ADD UNIQUE KEY `encounterID` (`encounterID`),
  ADD KEY `mapID` (`mapID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `encounter`
--
ALTER TABLE `encounter`
  ADD CONSTRAINT `encounter_ibfk_1` FOREIGN KEY (`mapID`) REFERENCES `map` (`mapID`);
COMMIT;
