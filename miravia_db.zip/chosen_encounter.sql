
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `chosen_encounter`
--

CREATE TABLE `chosen_encounter` (
  `chosenID` varchar(10) NOT NULL,
  `charID` varchar(10) NOT NULL,
  `eventID` varchar(10) NOT NULL,
  `shopID` varchar(10) NOT NULL,
  `chestID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chosen_encounter`
--

INSERT INTO `chosen_encounter` (`chosenID`, `charID`, `eventID`, `shopID`, `chestID`) VALUES
('1', '12', '2', '1', '12'),
('2', '22', '2', '2', '12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chosen_encounter`
--
ALTER TABLE `chosen_encounter`
  ADD PRIMARY KEY (`chosenID`),
  ADD UNIQUE KEY `chosenID` (`chosenID`),
  ADD KEY `charID` (`charID`),
  ADD KEY `chestID` (`chestID`),
  ADD KEY `eventID` (`eventID`),
  ADD KEY `shopID` (`shopID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chosen_encounter`
--
ALTER TABLE `chosen_encounter`
  ADD CONSTRAINT `chosen_encounter_ibfk_1` FOREIGN KEY (`charID`) REFERENCES `character` (`charID`),
  ADD CONSTRAINT `chosen_encounter_ibfk_2` FOREIGN KEY (`chestID`) REFERENCES `chest` (`chestID`),
  ADD CONSTRAINT `chosen_encounter_ibfk_3` FOREIGN KEY (`chosenID`) REFERENCES `chosen_encounter` (`chosenID`),
  ADD CONSTRAINT `chosen_encounter_ibfk_4` FOREIGN KEY (`eventID`) REFERENCES `random_event` (`eventID`),
  ADD CONSTRAINT `chosen_encounter_ibfk_5` FOREIGN KEY (`shopID`) REFERENCES `shop` (`shopID`);
COMMIT;
