
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `cardID` varchar(10) NOT NULL,
  `card_name` varchar(20) NOT NULL,
  `card_cost` int(2) NOT NULL,
  `card_damage` int(2) NOT NULL,
  `card_effect` varchar(10) DEFAULT NULL,
  `card_rarity` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`cardID`, `card_name`, `card_cost`, `card_damage`, `card_effect`, `card_rarity`) VALUES
('1', 'Knee Bash', 1, 3, 'Stun', 0.67),
('2', 'Shield Up', 1, 0, 'Shielded', 0.55),
('3', 'Fireball', 3, 5, 'Burn', 0.34);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`cardID`),
  ADD UNIQUE KEY `cardID` (`cardID`);
COMMIT;

