
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `enemy`
--

CREATE TABLE `enemy` (
  `npcID` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `HP` int(11) NOT NULL,
  `exp` int(11) NOT NULL,
  `intel` int(11) NOT NULL,
  `race` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enemy`
--

INSERT INTO `enemy` (`npcID`, `name`, `HP`, `exp`, `intel`, `race`) VALUES
('1', 'Grunt', 100, 20, 5, 'human'),
('2', 'Demon Boss', 400, 100, 10, 'Demon'),
('3', 'Hobbit', 50, 10, 10, 'Halfling');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enemy`
--
ALTER TABLE `enemy`
  ADD PRIMARY KEY (`npcID`);
COMMIT;
