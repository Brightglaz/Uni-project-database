
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `chest`
--

CREATE TABLE `chest` (
  `chestID` varchar(10) NOT NULL,
  `encounterID` varchar(10) NOT NULL,
  `chest_item` varchar(20) NOT NULL,
  `item_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chest`
--

INSERT INTO `chest` (`chestID`, `encounterID`, `chest_item`, `item_value`) VALUES
('12', '2', 'Socks', 10),
('3', '2', 'Wolf\'s Wool', 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chest`
--
ALTER TABLE `chest`
  ADD PRIMARY KEY (`chestID`),
  ADD UNIQUE KEY `chestID` (`chestID`),
  ADD KEY `encounterID` (`encounterID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chest`
--
ALTER TABLE `chest`
  ADD CONSTRAINT `chest_ibfk_1` FOREIGN KEY (`encounterID`) REFERENCES `encounter` (`encounterID`);
COMMIT;
