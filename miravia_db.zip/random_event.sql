
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `random_event`
--

CREATE TABLE `random_event` (
  `eventID` varchar(10) NOT NULL,
  `encounterID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `random_event`
--

INSERT INTO `random_event` (`eventID`, `encounterID`) VALUES
('1', '4'),
('2', '4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `random_event`
--
ALTER TABLE `random_event`
  ADD PRIMARY KEY (`eventID`),
  ADD UNIQUE KEY `eventID` (`eventID`),
  ADD KEY `encounterID` (`encounterID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `random_event`
--
ALTER TABLE `random_event`
  ADD CONSTRAINT `random_event_ibfk_1` FOREIGN KEY (`encounterID`) REFERENCES `encounter` (`encounterID`);
COMMIT;
