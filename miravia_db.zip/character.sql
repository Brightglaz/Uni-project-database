
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `character`
--

CREATE TABLE `character` (
  `charID` varchar(10) NOT NULL,
  `npcID` varchar(10) NOT NULL,
  `cardID` varchar(10) NOT NULL,
  `maxHP` int(3) NOT NULL,
  `userClass` int(2) NOT NULL,
  `gold` int(3) NOT NULL,
  `maxMana` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `character`
--

INSERT INTO `character` (`charID`, `npcID`, `cardID`, `maxHP`, `userClass`, `gold`, `maxMana`) VALUES
('1', '1', '1', 100, 2, 100, 50),
('12', '3', '3', 50, 3, 80, 100),
('22', '2', '2', 450, 10, 0, 50);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `character`
--
ALTER TABLE `character`
  ADD PRIMARY KEY (`charID`),
  ADD UNIQUE KEY `charID` (`charID`),
  ADD KEY `cardID` (`cardID`),
  ADD KEY `npcID` (`npcID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `character`
--
ALTER TABLE `character`
  ADD CONSTRAINT `character_ibfk_1` FOREIGN KEY (`cardID`) REFERENCES `card` (`cardID`),
  ADD CONSTRAINT `character_ibfk_2` FOREIGN KEY (`npcID`) REFERENCES `enemy` (`npcID`);
COMMIT;

