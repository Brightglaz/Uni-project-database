
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `shopID` varchar(10) NOT NULL,
  `encounterID` varchar(10) NOT NULL,
  `shop_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`shopID`, `encounterID`, `shop_name`) VALUES
('1', '3', 'Old\'s Trustee'),
('2', '3', 'Galaxy Pirate\'s');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`shopID`),
  ADD UNIQUE KEY `shopID` (`shopID`),
  ADD KEY `encounterID` (`encounterID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shop`
--
ALTER TABLE `shop`
  ADD CONSTRAINT `shop_ibfk_1` FOREIGN KEY (`encounterID`) REFERENCES `encounter` (`encounterID`);
COMMIT;
