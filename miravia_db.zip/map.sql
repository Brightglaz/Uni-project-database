
--
-- Database: `miravia_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `map`
--

CREATE TABLE `map` (
  `mapID` varchar(10) NOT NULL,
  `map_name` varchar(20) NOT NULL,
  `randomize_map` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `map`
--

INSERT INTO `map` (`mapID`, `map_name`, `randomize_map`) VALUES
('1', 'Ghoul\'s Heaven', 23),
('2', 'Farlands Forest', 44);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `map`
--
ALTER TABLE `map`
  ADD PRIMARY KEY (`mapID`),
  ADD UNIQUE KEY `mapID` (`mapID`);
COMMIT;
